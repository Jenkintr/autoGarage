/**
 * 
 */
package autoGarage;

/**
 * @author tjenkins20
 *
 */
public interface Vehicle {
	public void honk();
	public void move();
	public int getWheelNum();
	public int getDoorNum();
	public String getColor();
	public double getSpeed();
}
